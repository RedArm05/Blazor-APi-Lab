﻿namespace ApiAiBlazorLab.Models

{

    public class CatFact

    {

        public string fact { get; set; }

        public int length { get; set; }

    }

}